/* v65: Offline English dictionary for hadith translations. Tap a word for its meaning.
   Data: dict/v1/*.json (cache: lifemap-dict). Saved words: store.vocab, so they are in your backup. */
(function(){
 'use strict';
 const BASE='./dict/v1/',CN='lifemap-dict';
 /* English translation text only. Arabic text and buttons are left alone. */
 const AREAS='#hl .hl-e,#hl .hl-nr,.nwd .note2,[data-pk=l-hd] .lrn .note2,.kout .lrn .note2';
 const POS={n:'noun',v:'verb',a:'adjective',r:'adverb'};
 const E=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const V=()=>{store.vocab=store.vocab||{};return store.vocab;};
 const persist=()=>{try{save();}catch(e){}};
 const enabled=()=>!store.dictOff;
 const has=(o,k)=>!!o&&Object.prototype.hasOwnProperty.call(o,k);

 /* ---------- data ---------- */
 const mem={};
 function get(file){if(!mem[file])mem[file]=(async()=>{
   const u=BASE+file;let r=null;
   try{if(window.caches){const c=await caches.open(CN);r=await c.match(u);if(!r){const n=await fetch(u);if(n.ok){await c.put(u,n.clone()).catch(()=>{});r=n;}}}}catch(e){}
   if(!r)r=await fetch(u);
   if(!r.ok)throw new Error('dictionary');return r.json();})().catch(e=>{delete mem[file];throw e;});
  return mem[file];}
 let offline=0; /* 0 unknown, 1 saving, 2 saved */
 async function saveOffline(){if(!window.caches||offline)return;offline=1;
  try{const c=await caches.open(CN),r=await fetch(BASE+'index.json',{cache:'no-cache'});if(!r.ok)throw 0;const list=(await r.json()).files;
   for(const f of list){const u=BASE+f;if(!(await c.match(u))){const n=await fetch(u);if(!n.ok)throw 0;await c.put(u,n);}}
   offline=2;}catch(e){offline=0;
   try{const c=await caches.open(CN);if((await c.keys()).filter(q=>/\/dict\/v1\/([a-z]|core)\.json$/.test(q.url)).length>=27)offline=2;}catch(x){}}
  status();}

 /* Allah, rak'ah and Qur'an arrive with accents and curly marks: fold them to plain letters */
 const fold=s=>String(s||'').normalize('NFKD').replace(/[̀-ͯ]/g,'').replace(/[‘’ʼʿʾʻ`´]/g,"'").toLowerCase().replace(/^'+|'+$/g,'').replace(/[^a-z'-]/g,'');

 async function lookup(raw){
  const core=await get('core.json');
  let w=fold(raw);if(!w)return null;
  if(/'s$/.test(w)&&!has(core.b,w))w=w.slice(0,-2);
  const bare=w.replace(/'/g,'');
  const gkey=k=>has(core.g,k)?k:has(core.a,k)?core.a[k]:null;
  const out={word:w,gloss:[],basic:null,entries:[],pron:null};
  const addG=k=>{if(k&&!out.gloss.some(x=>x.k===k))out.gloss.push({k,v:core.g[k]});};
  addG(gkey(w)||(w.includes("'")?gkey(bare):null));
  if(has(core.b,w))out.basic=core.b[w];
  /* a word with an apostrophe inside is a contraction or an Arabic name: never guess an English word from it */
  const arabicG=out.gloss.length&&!out.gloss[0].v[2];
  if(!w.includes("'")&&!arabicG&&/^[a-z]/.test(w)){
   const sh=await get(w[0]+'.json'),f=has(sh.f,w)?sh.f[w]:null,own=has(sh.w,w)?w:null;
   let order=own?[own]:[];
   if(f){order=f.f?f.b.concat(order):order.concat(f.b);if(f.u)out.pron={u:f.u};}
   for(const k of order){
    const s=k[0]===w[0]?sh:await get(k[0]+'.json');
    if(has(s.w,k))out.entries.push({k,v:s.w[k]});
    addG(gkey(k));
    if(!out.basic&&has(core.b,k)&&!own)out.basic=core.b[k];
   }
  }
  if(!out.entries.length&&!out.gloss.length&&!out.basic&&w.includes('-')){
   const parts=w.split('-').filter(Boolean);if(parts.length>1){out.parts=parts;}}
  return out;}

 /* ---------- speech (uses the voices on the device) ---------- */
 let voices=[];
 const loadVoices=()=>{try{voices=speechSynthesis.getVoices()||[];}catch(e){}};
 if(window.speechSynthesis){loadVoices();try{speechSynthesis.addEventListener('voiceschanged',loadVoices);}catch(e){}}
 function speak(word,lang){if(!window.speechSynthesis){note('This device cannot play pronunciation.');return;}
  loadVoices();const norm=v=>v.lang.replace('_','-').toLowerCase(),m=voices.filter(v=>norm(v)===lang.toLowerCase());
  const v=m.find(x=>x.localService)||(navigator.onLine!==false?m[0]:null)||null;
  if(!v&&voices.length)note((lang==='en-GB'?'A British':'An American')+' voice is not available'+(navigator.onLine===false?' offline':'')+' on this device. Playing the default voice.');
  const u=new SpeechSynthesisUtterance(word);u.lang=lang;if(v)u.voice=v;u.rate=.85;
  try{speechSynthesis.cancel();speechSynthesis.speak(u);}catch(e){}}

 /* ---------- sheet ---------- */
 let root,box,isOpen=false,pushed=false,swallow=false,trail=[],cur=null,seq=0,opener=null;
 function css(){const s=document.createElement('style');s.textContent=`
#lmd{position:fixed;inset:0;z-index:3600;display:none;align-items:flex-end;justify-content:center;background:rgba(0,0,0,.35);color:var(--ink)}
#lmd.on{display:flex}
#lmd .dx{background:var(--card);width:100%;max-width:620px;max-height:72%;display:flex;flex-direction:column;border-radius:22px 22px 0 0;border:1px solid var(--line);border-bottom:0;box-shadow:0 -8px 30px rgba(0,0,0,.3);box-sizing:border-box;animation:lmdup .2s ease-out;padding-bottom:env(safe-area-inset-bottom,0px)}
@keyframes lmdup{from{transform:translateY(40%);opacity:.4}to{transform:none;opacity:1}}
@media (prefers-reduced-motion:reduce){#lmd .dx{animation:none}}
#lmd .dt{display:flex;align-items:center;gap:6px;padding:8px 10px 4px 18px}
#lmd .dt b{flex:1;font-size:13px;font-weight:600;color:var(--mut)}
#lmd button{font:inherit;color:inherit;background:none;border:0;min-height:0;min-width:0;cursor:pointer;margin:0}
#lmd .dt button{font-size:15px;padding:10px;color:var(--faith);font-weight:600}
#lmd .dt .xx{font-size:22px;color:var(--mut);line-height:1}
#lmd .db{overflow-y:auto;-webkit-overflow-scrolling:touch;padding:0 18px 16px;overscroll-behavior:contain}
#lmd h3{margin:2px 0;font-size:26px;font-weight:600;line-height:1.25;overflow-wrap:anywhere}
#lmd h4{margin:16px 0 4px;font-size:15px;font-weight:700;color:var(--faith)}
#lmd h4 small{font-weight:400;color:var(--mut);font-size:13px;margin-left:6px}
#lmd .say{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0}
#lmd .say button{border:1px solid var(--line);border-radius:999px;padding:7px 13px;font-size:14px}
#lmd .say button span{color:var(--mut);margin-left:6px}
#lmd .sv{width:100%;border:1px solid var(--faith)!important;border-radius:12px;padding:10px!important;color:var(--faith)!important;font-weight:600;margin:6px 0 2px!important}
#lmd .sv.on{background:var(--faith)!important;color:#fff!important}
#lmd .is{border:1px solid var(--line);border-left:4px solid var(--faith);border-radius:12px;padding:10px 12px;margin:10px 0}
#lmd .is small{display:block;color:var(--faith);font-weight:700;font-size:12px}
#lmd .is span[lang=ar]{float:right;font-size:20px;margin-left:10px}
#lmd p{margin:4px 0;line-height:1.55}
#lmd ol{margin:4px 0;padding-left:20px}#lmd li{margin:6px 0;line-height:1.5}
#lmd .ex{display:block;color:var(--mut);font-style:italic}
#lmd .rl{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:6px 0;font-size:13px;color:var(--mut)}
#lmd .rl button{border:1px solid var(--line);border-radius:999px;padding:5px 11px;color:var(--ink);font-size:14px}
#lmd .mu{color:var(--mut);font-size:13px}
#lmd .msg{color:var(--mut);font-size:13px;min-height:0}
#lmd .vr{display:flex;align-items:center;gap:8px;border-bottom:1px solid var(--line)}
#lmd .vr .go{flex:1;text-align:left;padding:12px 0}#lmd .vr .go b{display:block}#lmd .vr .go small{color:var(--mut)}
#lmd .vr .rm{color:var(--mut);padding:12px;font-size:16px}
::highlight(lmd){background:color-mix(in srgb,var(--faith) 38%,transparent)}
.lmd-hint{font-size:13px;color:var(--mut);text-align:center;margin:0 0 10px}`;document.head.appendChild(s);}
 function build(){if(root)return;root=document.createElement('div');root.id='lmd';
  root.innerHTML=`<div class='dx' role='dialog' aria-modal='true' aria-label='Dictionary' tabindex='-1'><div class='dt'><button data-d='back' hidden>‹ Back</button><b>Dictionary</b><button data-d='list'>My words</button><button class='xx' data-d='close' aria-label='Close'>✕</button></div><div class='db' aria-live='polite'></div></div>`;
  document.body.appendChild(root);box=root.querySelector('.db');root.addEventListener('click',onClick);}
 function show(){build();if(isOpen)return;isOpen=true;opener=document.activeElement;root.classList.add('on');
  /* an extra history step, so the phone's Back button closes only the dictionary */
  try{history.pushState(Object.assign({},history.state||{},{lmd:1}),'');pushed=true;}catch(e){pushed=false;}
  root.querySelector('.dx').focus({preventScroll:true});saveOffline();}
 function close(fromPop){if(!isOpen)return;isOpen=false;trail=[];cur=null;seq++;root.classList.remove('on');mark(null);
  try{speechSynthesis.cancel();}catch(e){}
  const ct=document.querySelector('#hl .hl-b>[data-lmd] .ct');if(ct)ct.textContent=Object.keys(V()).length;
  if(!fromPop&&pushed){swallow=true;try{history.back();}catch(e){swallow=false;}}pushed=false;
  try{if(opener&&opener.focus)opener.focus({preventScroll:true});}catch(e){}}
 window.addEventListener('popstate',e=>{if(swallow){swallow=false;e.stopImmediatePropagation();return;}if(isOpen){e.stopImmediatePropagation();close(true);}},true);
 document.addEventListener('keydown',e=>{if(isOpen&&e.key==='Escape'){e.stopImmediatePropagation();e.preventDefault();close();}},true);
 function note(m){const n=box&&box.querySelector('.msg');if(n)n.textContent=m;}
 function status(){const n=box&&box.querySelector('.os');if(n)n.textContent=offline===2?'Saved for offline use ✓':offline===1?'Saving the dictionary for offline use…':'';}

 const chips=(label,L)=>L&&L.length?`<div class='rl'>${label}${L.map(x=>`<button data-d='w' data-w='${E(x)}'>${E(x)}</button>`).join('')}</div>`:'';
 function sayRow(word,gb,us,other){const b=(lang,label,ipa)=>`<button data-d='say' data-l='${lang}' data-w='${E(word)}' aria-label='Play ${label} pronunciation'>🔊 ${label}${ipa?`<span>/${E(ipa)}/</span>`:''}</button>`;
  return `<div class='say'>${b('en-GB','UK',gb)}${b('en-US','US',us)}</div>${!gb&&!us&&other?`<div class='mu'>/${E(other)}/</div>`:''}`;}
 function sense(s){return `<li>${E(s[0])}${s[1]?`<span class='ex'>“${E(s[1])}”</span>`:''}</li>`;}
 function render(r,raw,ref){
  const w=r.word,first=r.entries[0],exact=r.entries.find(x=>x.k===w),V0=V(),saved=has(V0,w);
  const head=raw.replace(/^[^\p{L}]+|[^\p{L}]+$/gu,'').replace(/['’]s$/,'');
  const gb=exact&&exact.v.g,us=(exact&&exact.v.u)||(r.pron&&r.pron.u)||(r.basic&&r.basic[3])||(r.gloss[0]&&r.gloss[0].k===w&&r.gloss[0].v[3])||'';
  const found=r.entries.length||r.gloss.length||r.basic;
  let h=`<h3>${E(head||w)}</h3>`;
  if(first&&first.k!==w&&!exact)h+=`<div class='mu'>A form of <b>${E(first.k)}</b></div>`;
  h+=sayRow(w,gb,us,exact&&exact.v.i)+`<div class='msg' role='status'></div>`;
  r.gloss.forEach(g=>{h+=`<div class='is'>${g.v[0]?`<span lang='ar' dir='rtl'>${E(g.v[0])}</span>`:''}<small>Islamic term</small><p>${E(g.v[1])}</p></div>`;});
  if(r.basic)h+=`<h4>${E(r.basic[0])}</h4><p>${E(r.basic[1])}</p>`;
  r.entries.forEach(en=>{const diff=en.k!==w;
   if(diff)h+=`<h4>${E(en.k)}<small>${[en.v.g&&'UK /'+en.v.g+'/',en.v.u&&'US /'+en.v.u+'/'].filter(Boolean).map(E).join(' · ')}</small></h4>`;
   en.v.s.forEach(p=>{h+=`<h4>${POS[p[0]]||''}</h4><ol>${p[1].map(sense).join('')}</ol>${chips('Synonyms',p[2])}${chips('Opposites',p[3])}`;});});
  if(!found){h+=`<p>No definition found. It may be a name, an Arabic word or a spelling that is not in this dictionary.</p>`+chips('Look up a part:',r.parts);}
  else h+=`<button class='sv${saved?' on':''}' data-d='save' aria-pressed='${saved}'>${saved?'Saved to My words ✓':'Save to My words'}</button>`;
  h+=`<p class='mu os'></p><p class='mu'>Meanings are general dictionary meanings and may not match this hadith exactly. Check Islamic terms with a qualified teacher. Sources: Open English WordNet 2024 (CC BY 4.0), based on Princeton WordNet, with edits; US pronunciation from ipa-dict (MIT).</p>`;
  box.innerHTML=h;box.scrollTop=0;status();cur={v:'word',w,raw,ref};}
 async function open(raw,ref,nested){show();if(nested&&cur)trail.push(cur);else if(!nested)trail=[];
  const n=++seq;root.querySelector('[data-d=back]').hidden=!trail.length;
  box.innerHTML=`<h3>${E(raw)}</h3><p class='mu'>Looking up…</p>`;cur={v:'word',w:fold(raw),raw,ref};
  try{const r=await lookup(raw);if(n!==seq)return;if(!r){close();return;}render(r,raw,ref);}
  catch(e){if(n!==seq)return;box.innerHTML=`<h3>${E(raw)}</h3><p>The dictionary is not saved on this device yet. Connect to the internet once and try again.</p><button class='sv' data-d='w' data-w='${E(raw)}'>Try again</button>`;}}
 function list(){show();seq++;cur={v:'list'};root.querySelector('[data-d=back]').hidden=!trail.length;
  const L=Object.entries(V()).sort((a,b)=>(b[1].t||0)-(a[1].t||0));
  box.innerHTML=`<h3>My words</h3><p class='mu'>${L.length?L.length+' saved':'No saved words yet. Tap a word in a translation, then “Save to My words”.'}</p>`+
   L.map(([k,v])=>`<div class='vr'><button class='go' data-d='w' data-w='${E(k)}'><b>${E(k)}</b>${v.ref?`<small>${E(v.ref)}</small>`:''}</button><button class='rm' data-d='rm' data-w='${E(k)}' aria-label='Remove ${E(k)}'>✕</button></div>`).join('')+`<div class='msg' role='status'></div>`;
  box.scrollTop=0;}
 function onClick(e){if(e.target===root){close();return;}const t=e.target.closest('[data-d]');if(!t)return;const a=t.dataset.d;
  if(a==='close')close();
  else if(a==='list'){if(cur&&cur.v!=='list')trail.push(cur);list();}
  else if(a==='back'){const p=trail.pop();if(!p)return;if(p.v==='list')list();else{cur=null;const keep=trail.slice();open(p.raw,p.ref);trail=keep;root.querySelector('[data-d=back]').hidden=!trail.length;}}
  else if(a==='w'){const retry=cur&&cur.w===fold(t.dataset.w);const v=V()[t.dataset.w];open(t.dataset.w,v?v.ref:(cur&&cur.ref)||'',!retry);}
  else if(a==='say')speak(t.dataset.w,t.dataset.l);
  else if(a==='save'&&cur&&cur.v==='word'){const v=V();if(has(v,cur.w))delete v[cur.w];else v[cur.w]={t:Date.now(),ref:cur.ref||''};persist();
   const on=has(v,cur.w);t.classList.toggle('on',on);t.setAttribute('aria-pressed',on);t.textContent=on?'Saved to My words ✓':'Save to My words';}
  else if(a==='rm'){delete V()[t.dataset.w];persist();list();}}

 /* ---------- finding the tapped word (the page text itself is not changed) ---------- */
 const LETTER=/[\p{L}\p{M}'’‘ʿʾʼ`-]/u;
 function wordAt(x,y,area){
  let node=null,off=0;
  if(document.caretPositionFromPoint){const p=document.caretPositionFromPoint(x,y);if(p){node=p.offsetNode;off=p.offset;}}
  else if(document.caretRangeFromPoint){const r=document.caretRangeFromPoint(x,y);if(r){node=r.startContainer;off=r.startOffset;}}
  if(!node||node.nodeType!==3||!area.contains(node))return null;
  const s=node.nodeValue;let a=Math.min(off,s.length),b=a;
  while(a>0&&LETTER.test(s[a-1]))a--;while(b<s.length&&LETTER.test(s[b]))b++;
  while(a<b&&!/\p{L}/u.test(s[a]))a++;while(b>a&&!/\p{L}/u.test(s[b-1]))b--;
  if(a>=b)return null;
  const word=s.slice(a,b);if(!/[A-Za-zÀ-ɏḀ-ỿ]/.test(word))return null;
  const range=document.createRange();range.setStart(node,a);range.setEnd(node,b);
  /* ignore taps on blank space beside the text */
  const hit=Array.from(range.getClientRects()).some(q=>x>=q.left-3&&x<=q.right+3&&y>=q.top-3&&y<=q.bottom+3);
  /* the app's text-size setting uses CSS zoom, which some browsers report in unzoomed units */
  const z=parseFloat(getComputedStyle(document.body).zoom)||1;
  const hitZ=!hit&&z!==1&&Array.from(range.getClientRects()).some(q=>x>=q.left*z-3&&x<=q.right*z+3&&y>=q.top*z-3&&y<=q.bottom*z+3);
  return hit||hitZ?{word,range}:null;}
 function mark(range){try{if(!window.CSS||!CSS.highlights)return;if(range)CSS.highlights.set('lmd',new Highlight(range));else CSS.highlights.delete('lmd');}catch(e){}}
 function refOf(area){const card=area.closest('.hl-h');
  if(card){const p=(card.dataset.k||'').split('|'),b=((window.HLIDX&&window.HLIDX.books)||[]).find(x=>x.id===p[0]);return (b?b.en:p[0])+' '+(card.dataset.n||p[2]||'');}
  const nw=area.closest('.nw');if(nw)return 'Forty Hadith of an-Nawawi '+nw.dataset.n;return '';}
 let hadSelection=false;
 document.addEventListener('pointerdown',()=>{const s=window.getSelection&&getSelection();hadSelection=!!(s&&!s.isCollapsed);},true);
 document.addEventListener('click',e=>{
  if(!enabled()||e.defaultPrevented||e.button||!e.target.closest)return;
  const area=e.target.closest(AREAS);if(!area||e.target.closest('a,button,input,summary,label'))return;
  const s=window.getSelection&&getSelection();if(hadSelection||(s&&!s.isCollapsed))return;
  const hit=wordAt(e.clientX,e.clientY,area);if(!hit)return;
  mark(hit.range);open(hit.word,refOf(area));});

 /* ---------- reader additions: hint, on/off switch ---------- */
 function toggleLabel(){return enabled()?'Tap a word for its meaning: On':'Tap a word for its meaning: Off';}
 function enhance(){const hl=document.getElementById('hl');if(!hl)return;
  const fp=hl.querySelector('.hl-fp');
  if(fp&&!fp.querySelector('[data-lmd]')){const b=document.createElement('button');b.type='button';b.className='rs';b.setAttribute('data-lmd','tog');b.textContent=toggleLabel();fp.appendChild(b);
   const m=document.createElement('button');m.type='button';m.className='rs';m.setAttribute('data-lmd','list');m.textContent='My words';fp.appendChild(m);}
  const ch=hl.querySelector('.hl-b>.hl-ch');
  const mk=hl.querySelector('.hl-b>[data-hl=mk]');
  if(mk&&!hl.querySelector('.hl-b>[data-lmd]'))mk.insertAdjacentHTML('afterend',`<div class='hl-sc'><b>Vocabulary</b></div><button type='button' class='hl-row' data-lmd='list'><span class='tx'><b>My words</b></span><span class='ct'>${Object.keys(V()).length}</span></button>`);
  if(ch&&enabled()&&!hl.querySelector('.lmd-hint')){const p=document.createElement('div');p.className='lmd-hint';p.textContent='Tap any English word to see its meaning.';ch.insertAdjacentElement('afterend',p);}}
 document.addEventListener('click',e=>{const t=e.target.closest&&e.target.closest('[data-lmd]');if(!t)return;
  if(t.dataset.lmd==='tog'){store.dictOff=enabled()?1:0;persist();t.textContent=toggleLabel();const h=document.querySelector('.lmd-hint');if(h)h.remove();enhance();}
  else list();},true);
 function watch(){let q=false;const run=()=>{q=false;enhance();};
  new MutationObserver(()=>{const hl=document.getElementById('hl');if(hl&&!q){q=true;requestAnimationFrame(run);}}).observe(document.body,{childList:true,subtree:true});run();}
 css();watch();
 /* save the dictionary quietly after the app has settled, so it is ready without internet */
 setTimeout(()=>{if(navigator.onLine!==false&&!(navigator.connection&&navigator.connection.saveData))saveOffline();},6000);
 window.LMDict={open,list,lookup,close};
})();
