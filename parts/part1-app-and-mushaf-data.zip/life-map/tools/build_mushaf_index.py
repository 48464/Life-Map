# Builds mushaf/index.json (surah start pages + juz start pages) from mushaf/QPC1/page-XXX.json.
import json,glob,re
EN="Al-Fatihah,Al-Baqarah,Ali 'Imran,An-Nisa,Al-Ma'idah,Al-An'am,Al-A'raf,Al-Anfal,At-Tawbah,Yunus,Hud,Yusuf,Ar-Ra'd,Ibrahim,Al-Hijr,An-Nahl,Al-Isra,Al-Kahf,Maryam,Ta-Ha,Al-Anbiya,Al-Hajj,Al-Mu'minun,An-Nur,Al-Furqan,Ash-Shu'ara,An-Naml,Al-Qasas,Al-'Ankabut,Ar-Rum,Luqman,As-Sajdah,Al-Ahzab,Saba,Fatir,Ya-Sin,As-Saffat,Sad,Az-Zumar,Ghafir,Fussilat,Ash-Shura,Az-Zukhruf,Ad-Dukhan,Al-Jathiyah,Al-Ahqaf,Muhammad,Al-Fath,Al-Hujurat,Qaf,Adh-Dhariyat,At-Tur,An-Najm,Al-Qamar,Ar-Rahman,Al-Waqi'ah,Al-Hadid,Al-Mujadila,Al-Hashr,Al-Mumtahanah,As-Saff,Al-Jumu'ah,Al-Munafiqun,At-Taghabun,At-Talaq,At-Tahrim,Al-Mulk,Al-Qalam,Al-Haqqah,Al-Ma'arij,Nuh,Al-Jinn,Al-Muzzammil,Al-Muddaththir,Al-Qiyamah,Al-Insan,Al-Mursalat,An-Naba,An-Nazi'at,'Abasa,At-Takwir,Al-Infitar,Al-Mutaffifin,Al-Inshiqaq,Al-Buruj,At-Tariq,Al-A'la,Al-Ghashiyah,Al-Fajr,Al-Balad,Ash-Shams,Al-Layl,Ad-Duha,Ash-Sharh,At-Tin,Al-'Alaq,Al-Qadr,Al-Bayyinah,Az-Zalzalah,Al-'Adiyat,Al-Qari'ah,At-Takathur,Al-'Asr,Al-Humazah,Al-Fil,Quraysh,Al-Ma'un,Al-Kawthar,Al-Kafirun,An-Nasr,Al-Masad,Al-Ikhlas,Al-Falaq,An-Nas".split(',')
assert len(EN)==114
JUZ=[1,22,42,62,82,102,122,142,162,182,202,222,242,262,282,302,322,342,362,382,402,422,442,462,482,502,522,542,562,582]
S={}
for p in range(1,605):
    d=json.load(open('mushaf/QPC1/page-%03d.json'%p,encoding='utf8'))
    for l in d['lines']:
        if l['type']=='surah-header':
            n=int(l['surah']);S.setdefault(n,{'n':n,'ar':l['text'],'en':EN[n-1],'p':p})
assert len(S)==114,len(S)
# verify juz start pages against the data: first verse of each juz page should be verse 1 of the expected sura:verse
JV=[(1,1),(2,142),(2,253),(3,93),(4,24),(4,148),(5,82),(6,111),(7,88),(8,41),(9,93),(11,6),(12,53),(15,1),(17,1),(18,75),(21,1),(23,1),(25,21),(27,56),(29,46),(33,31),(36,28),(39,32),(41,47),(46,1),(51,31),(58,1),(67,1),(78,1)]
res=[]
for j,(s,v) in enumerate(JV,1):
    pg=None
    for p in range(1,605):
        d=json.load(open('mushaf/QPC1/page-%03d.json'%p,encoding='utf8'))
        for l in d['lines']:
            for w in l.get('words',[]):
                if w['location']==f'{s}:{v}:1' and pg is None: pg=p
        if pg: break
    res.append(pg)
print(res)
json.dump({'surahs':[S[i] for i in range(1,115)],'juz':res},open('mushaf/index.json','w',encoding='utf8'),ensure_ascii=False,separators=(',',':'))
