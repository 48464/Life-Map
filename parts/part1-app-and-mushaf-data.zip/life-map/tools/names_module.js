/* v34: Names of Allah (Learn card + Today "name of the day"). Data: names.json (tools/build_names.py). */
(function(){
 const E=v=>String(v==null?'':v).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 let ND=null;const learned=()=>Array.isArray(store.set.nl)?store.set.nl:[];
 const norm=t=>String(t||'').toLowerCase().replace(/[ً-ٰٟ]/g,'').replace(/[^a-z0-9ء-ي ]/g,' ').replace(/\s+/g,' ').trim();
 const hadith=`<div class='note2'>“Allah has ninety-nine names, one hundred minus one; whoever knows them (ahsaha) will enter Paradise.”<br><b>Bukhari · Conditions (reader #2624); also Muslim</b> · Sahih. Scholars differ on the exact list of ninety-nine; this list follows the one you provided.</div>`;
 const row=(n,open)=>`<div class='lrn nm' data-n='${n.id}' data-s='${E(norm(n.tr+' '+n.en+' '+n.ar))}'><div style='display:flex;align-items:center;gap:10px'><span class='sub' style='min-width:26px'>${n.id}</span><div style='flex:1'><div class='ar' lang='ar' dir='rtl' style='font-size:22px'>${E(n.ar)}</div><b>${E(n.tr)}</b> <span class='sub'>· ${E(n.en)}</span></div><button class='chipb${learned().includes(n.id)?' on':''}' data-nl='${n.id}'>${learned().includes(n.id)?'✓ Learned':'Learn'}</button></div>${open?`<div class='ar' lang='ar' dir='rtl' style='margin-top:6px'>${E(n.def)}</div>`:''}</div>`;
 function learnHTML(){if(!ND)return '';const L=learned().length;
  return `<div class='card pc min' data-pk='l-names'><div class='ttl phead' role='button' tabindex='0' aria-expanded='false'>Names of Allah <small style='font-weight:400;margin-left:6px'>${L}/${ND.length} learned</small></div>
  ${hadith}<input id='nsq' placeholder='Search a name…' style='width:100%;margin:8px 0;padding:10px;border-radius:10px;border:1px solid var(--line,#8886);background:transparent;color:inherit;font:inherit'><div id='nlist'>${ND.map(n=>row(n,false)).join('')}</div></div>`;}
 function today(){return ND?ND[Math.floor(parse(cur).getTime()/86400000+0.5)%ND.length]:null;}
 function ensure(){let h=document.getElementById('nmcard');if(h)return h;const a=document.getElementById('fjcard')||document.getElementById('azkar');if(!a)return null;h=document.createElement('div');h.id='nmcard';h.className='card pc vt min';h.dataset.pk='p-name';a.insertAdjacentElement('afterend',h);return h;}
 function drawToday(){const n=today();if(!n)return;const h=ensure();if(!h)return;
  h.innerHTML=`<div class='ttl phead' role='button' tabindex='0' aria-expanded='false'>Name of the day <small style='font-weight:400;margin-left:6px'>${E(n.tr)}</small></div>
  <div class='ar' lang='ar' dir='rtl' style='font-size:30px;text-align:center;margin:6px 0'>${E(n.ar)}</div><div style='text-align:center'><b>${E(n.tr)}</b> · ${E(n.en)}</div>
  <div class='ar' lang='ar' dir='rtl' style='margin-top:8px'>${E(n.def)}</div><div class='sunb' style='display:flex;gap:6px;margin:8px 0'><button class='chipb${learned().includes(n.id)?' on':''}' data-nl='${n.id}'>${learned().includes(n.id)?'✓ Learned':'Mark as learned'}</button></div>${hadith}`;
  try{applyMin();}catch(e){}}
 document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('[data-nl]');if(b){const id=+b.dataset.nl,l=learned().slice(),i=l.indexOf(id);if(i>=0)l.splice(i,1);else l.push(id);store.set.nl=l;save();try{drawToday();drawLearn();}catch(x){}return;}
  const r=e.target.closest&&e.target.closest('#nlist .nm');if(r&&!e.target.closest('button')){const n=ND[+r.dataset.n-1],o=r.querySelector('.ar[dir=rtl]+*'),ex=r.querySelector('.nd');if(ex)ex.remove();else r.insertAdjacentHTML('beforeend',`<div class='nd ar' lang='ar' dir='rtl' style='margin-top:6px'>${E(n.def)}</div>`);}});
 document.addEventListener('input',e=>{const i=e.target;if(i.id!=='nsq')return;const q=norm(i.value);document.querySelectorAll('#nlist .nm').forEach(n=>{n.style.display=!q||(n.dataset.s||'').includes(q)?'':'none';});});
 const _dl=drawLearn;drawLearn=function(){_dl();const el=document.getElementById('learn');if(!el)return;el.querySelectorAll('[data-pk=l-names]').forEach(n=>n.remove());const t=el.querySelector('[data-pk=l-sun]');const h=learnHTML();if(t)t.insertAdjacentHTML('afterend',h);else el.insertAdjacentHTML('afterbegin',h);try{applyMin();}catch(e){}};
 const _r=render;render=function(){_r();try{drawToday();}catch(e){}};
 fetch('names.json').then(r=>r.ok?r.json():null).then(j=>{ND=j;try{render();drawLearn();}catch(e){}}).catch(()=>{});
})();
