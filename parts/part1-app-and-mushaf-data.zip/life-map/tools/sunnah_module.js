/* v33: Fasting calendar (wajib / sunnah / not allowed), Jumu'ah checklist, forty-hadith quotes.
   Evidence in sunnah.json (built by tools/build_sunnah.py). Hijri dates use Umm al-Qura where the phone supports it,
   so a day can differ by one from your local moon-sighting: always confirm Ramadan / Eid with your local authority. */
(function(){
 const E=v=>String(v==null?'':v).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const SS=()=>store.set,SR=()=>Object.assign({on:1,fast:1,fri:1},SS().sr||{});
 let SD=null;
 const KIND={wajib:['Obligatory','#b42318'],sunnah:['Sunnah','#15803d'],bar:['Not allowed','#b42318'],avoid:['Better to avoid','#b45309']};
 /* ---- new measured items ---- */
 const F=DOMS.faith.items,gi=id=>F.findIndex(i=>i[0]===id);
 if(gi('sfast')>=0)F[gi('sfast')][1]='Sunnah fast (Mon / Thu / white days / Shawwal…)';
 if(gi('jumuah')>=0){F[gi('jumuah')][1]='Jumu’ah prayer (Friday, wajib on men)';
  F.splice(gi('jumuah')+1,0,['j_ghusl','Friday sunnah: ghusl, siwak, best clothes, go early',1],['j_kahf','Friday sunnah: Surat al-Kahf',1],['j_dua','Friday sunnah: salawat & dua before Maghrib',1]);}
 F.splice(gi('sfast')+1,0,['fast_w','Fast today (wajib: Ramadan)'],['fast_q','Make-up (qada) fast',1]);
 /* ---- Hijri / fasting rules ---- */
 const hp=s=>{try{return hijriParts(parse(s));}catch(e){return null;}},cache={};
 const exc=s=>!!(store.days[s]&&store.days[s].fx);
 function info(s){if(cache[s])return cache[s];const p=hp(s),o={s,p,w:parse(s).getDay(),wajib:null,sun:[],bar:[],avoid:[]};cache[s]=o;if(!p)return o;
  const m=p.month,d=p.day;
  if(m===9)o.wajib={k:'ramadan',t:'Ramadan fast'};
  else if(m===10&&d===1)o.bar.push({k:'eid',t:'‘Eid al-Fitr'});
  else if(m===12&&d===10)o.bar.push({k:'eid',t:'‘Eid al-Adha'});
  else if(m===12&&d>=11&&d<=13)o.bar.push({k:'tashreeq',t:'Days of Tashreeq'});
  if(!o.bar.length&&!o.wajib){
   if(m===12&&d===9)o.sun.push({k:'arafah',t:'Day of ‘Arafah (not for pilgrims)'});
   else if(m===12&&d<=8)o.sun.push({k:'dh',t:'Dhul-Hijjah, day '+d});
   if(m===1&&d===10)o.sun.push({k:'ashura',t:'‘Ashura (10 Muharram)'});
   if(m===1&&d===9)o.sun.push({k:'ashura',t:'Tasu‘a (9 Muharram, with ‘Ashura)'});
   if(m===10&&d>=2)o.sun.push({k:'shawwal',t:'Six days of Shawwal'});
   if(d>=13&&d<=15)o.sun.push({k:'white',t:'White day ('+d+')'});
   if(m===8&&d<=15)o.sun.push({k:'shaban',t:'Sha‘ban'});
   if(o.w===1||o.w===4)o.sun.push({k:'monthu',t:o.w===1?'Monday':'Thursday'});
   const q1=hp(addDays(s,1)),q2=hp(addDays(s,2));
   if(m===8&&((q1&&q1.month===9&&q1.day===1)||(q2&&q2.month===9&&q2.day===1))){o.avoid.push({k:'pre',t:'1–2 days before Ramadan'});o.sun=o.sun.filter(x=>x.k!=='shaban');}
   if(o.w===5&&!o.sun.some(x=>['arafah','ashura','white','shawwal','dh'].includes(x.k))&&!has(addDays(s,-1),'sfast'))o.avoid.push({k:'friday',t:'Friday alone'});
  }
  return o;}
 const qada=()=>Math.max(0,+SS().qada||0);
 const jmOn=()=>(SS().jm||'w')!=='n';
 /* applicability for scoring: wajib fast only on Ramadan days (not when excused); make-up only while owed; Jumu'ah unless set to N/A */
 APP.fast_w=s=>{const i=info(s);return !!i.wajib&&!exc(s);};
 APP.fast_q=s=>qada()>0||has(s,'fast_q');
 APP.jumuah=jmOn;
 /* ---- scoring hooks ---- */
 const naWin=it=>{const f=APP[it[0]];if(!f)return false;if(it[2])return !f(todayStr());const w=win(),t=todayStr();for(let j=0;j<Math.max(1,w);j++)if(f(addDays(t,-j)))return false;return true;};
 window.naWin=naWin;
 /* ---- UI ---- */
 const css=document.createElement('style');css.textContent=`.sk{display:inline-block;color:#fff;border-radius:8px;padding:1px 7px;font-size:11px;font-weight:700;margin-right:6px;vertical-align:1px}.sunr{padding:8px 0;border-top:1px solid var(--line,#8883)}.sunr:first-child{border-top:0}.sunb{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}.suns select{max-width:100%}`;document.head.appendChild(css);
 const evH=a=>(a||[]).map(x=>`<div class='note2' style='margin:6px 0'>“${E(x.en)}”<br><b>${E(x.ref)}</b> · ${E(x.g)}${x.s==='T'?' <span class="sub">(standard translation)</span>':''}</div>`).join('');
 const FQ=k=>SD&&SD.fasts[k];
 const kindOf=(k)=>{const f=FQ(k);return f?f.k:'sunnah';};
 const bad=k=>{const b=KIND[k==='haram'?'bar':k==='makruh'?'avoid':k];return `<span class='sk' style='background:${b[1]}'>${b[0]}</span>`;};
 function shawwalCount(s){let c=0;for(let j=0;j<32;j++){const d=addDays(s,-j),p=hp(d);if(p&&p.month===10&&has(d,'sfast'))c++;}return c;}
 function tag(it,s){const f=FQ(it.k);return `<div class='sunr'>${bad(it.k==='eid'||it.k==='tashreeq'?'bar':it.k==='pre'||it.k==='friday'?'avoid':'sunnah')}<b>${E(it.t)}</b>${f?`<div class='note2'>${E(f.rule)}</div>`:''}${it.k==='shawwal'?`<div class='note2'>Fasted so far this Shawwal: ${shawwalCount(s)}/6</div>`:''}<details class='ldt'><summary>Evidence</summary>${evH(f&&f.ev)}</details></div>`;}
 function summary(s){const i=info(s),a=[];if(i.wajib)a.push(exc(s)?'Ramadan (excused today)':'Wajib: Ramadan fast');else if(i.bar.length)a.push('No fasting: '+i.bar[0].t);else if(i.sun.length)a.push('Sunnah fast: '+i.sun[0].t);else if(i.avoid.length)a.push('Better not to fast alone');
  if(i.w===5)a.push('Jumu’ah');return a.join(' · ')||'No special fast today';}
 function upcoming(s){const o=[];for(let j=1;j<=30&&o.length<6;j++){const d=addDays(s,j),i=info(d);let l='';
   if(i.wajib&&info(addDays(d,-1)).wajib===null)l=['wajib','Ramadan begins'];else if(i.bar.length)l=['bar',i.bar[0].t];else{const x=i.sun.find(q=>q.k!=='monthu'&&q.k!=='shaban'&&q.k!=='shawwal'&&q.k!=='white'||(q.k==='white'&&i.p.day===13));if(x)l=['sunnah',x.t];}
   if(l)o.push([d,l]);}return o;}
 function ensure(){let h=document.getElementById('fjcard');if(h)return h;const a=document.getElementById('azkar');if(!a)return null;h=document.createElement('div');h.id='fjcard';h.className='card pc vt min suns';h.dataset.pk='p-sunnah';a.insertAdjacentElement('afterend',h);
  h.addEventListener('click',onClick);h.addEventListener('change',onChange);return h;}
 function draw(){const h=ensure();if(!h)return;const s=cur,i=info(s),sr=SR(),ex=exc(s),fri=i.w===5;
  let b='';
  const hs=i.p?`${HIJM[i.p.month-1]} ${i.p.day}, ${i.p.year} AH`:'';
  b+=`<div class='note2'>${E(hs)} · Hijri date is calculated (Umm al-Qura); confirm Ramadan and Eid with your local sighting.</div>`;
  if(i.wajib){const f=FQ('ramadan');b+=`<div class='sunr'>${bad('wajib')}<b>Ramadan fast</b><div class='note2'>${E(f?f.rule:'')}</div>
   <div class='sunb'><button class='chipb${has(s,'fast_w')?' on':''}' data-a='t' data-id='fast_w'>${has(s,'fast_w')?'✓ ':''}I fasted today</button><button class='chipb${ex?' on':''}' data-a='ex'>${ex?'✓ ':''}Excused today (illness, travel, menses)</button></div>
   <div class='note2'>${ex?'Excused: not counted against your score; this day is added to your make-up (qada) count.':'Wajib: counted in today’s score. If you are excused, tap Excused.'}</div><details class='ldt'><summary>Evidence</summary>${evH(f&&f.ev)}</details></div>`;}
  i.bar.forEach(x=>{b+=tag(x,s);});
  if(!i.wajib&&i.sun.length){b+=i.sun.map(x=>tag(x,s)).join('')+`<div class='sunb'><button class='chipb${has(s,'sfast')?' on':''}' data-a='t' data-id='sfast'>${has(s,'sfast')?'✓ ':''}I fasted today (sunnah)</button></div>`;}
  i.avoid.forEach(x=>{b+=tag(x,s);});
  if(!i.wajib&&!i.bar.length&&!i.sun.length&&!i.avoid.length)b+=`<div class='note2'>No special fasting day today.</div>`;
  /* qada */
  const q=qada();b+=`<div class='sunr'>${bad('wajib')}<b>Make-up (qada) days owed: ${q}</b><div class='sunb'><button class='chipb' data-a='q' data-d='-1'>−1</button><button class='chipb' data-a='q' data-d='1'>+1</button>${q>0&&!i.bar.length&&!i.wajib?`<button class='chipb${has(s,'fast_q')?' on':''}' data-a='mk'>${has(s,'fast_q')?'✓ ':''}I made up a day today</button>`:''}</div><details class='ldt'><summary>Evidence</summary>${evH((FQ('qada')||{}).ev)}</details></div>`;
  const up=upcoming(s);if(up.length)b+=`<div class='sunr'><b>Coming up</b>${up.map(([d,l])=>`<div class='note2'>${bad(l[0])}${parse(d).toLocaleDateString(LOC(),{weekday:'short',day:'numeric',month:'short'})} · ${E(l[1])}</div>`).join('')}<div class='note2'>Mondays, Thursdays and the 13th–15th are sunnah every month.</div></div>`;
  /* Friday */
  const nj=(5-i.w+7)%7;
  b+=`<div class='sunr'><b>Jumu’ah (Friday)</b>`;
  if(fri||nj<=1){
   b+=`<div class='note2'>${fri?'Today is Friday.':'Tomorrow is Friday: prepare tonight.'}</div>`;
   const row=(id,t,k,kind)=>`<div class='sunb' style='margin:4px 0'><button class='chipb${has(s,id)?' on':''}' data-a='t' data-id='${id}'>${has(s,id)?'✓ ':''}${t}</button></div><details class='ldt'><summary>Evidence</summary>${evH(((SD&&SD.friday[k])||{}).ev)}</details>`;
   if(jmOn())b+=`<div style='margin-top:6px'>${bad('wajib')}<b>Attend Jumu’ah prayer</b></div>`+row('jumuah','Prayed Jumu’ah','obl');
   else b+=`<div class='note2'>Marked not obligatory on me: you pray Dhuhr instead.</div>`;
   b+=`<div style='margin-top:6px'>${bad('sunnah')}<b>Friday sunnahs</b></div>`+row('j_ghusl','Ghusl, siwak, best clothes, perfume, go early','ghusl')+row('j_kahf','Read Surat al-Kahf','kahf')+row('j_dua','Salawat & dua, last hour before Maghrib','dua');
  }else b+=`<div class='note2'>Next Jumu’ah in ${nj} day${nj>1?'s':''}.</div>`;
  b+=`<div class='note2' style='margin-top:6px'>Jumu’ah applies to me: <select data-a='jm'><option value='w'${jmOn()?' selected':''}>Yes, obligatory (adult resident man)</option><option value='n'${jmOn()?'':' selected'}>No (woman, traveller, excused)</option></select></div></div>`;
  b+=`<div class='sunr'><b>Priority reminders</b><div class='sunb'><button class='chipb${sr.on?' on':''}' data-a='r' data-k='on'>${sr.on?'✓ ':''}On</button><button class='chipb${sr.fast?' on':''}' data-a='r' data-k='fast'>${sr.fast?'✓ ':''}Fasting</button><button class='chipb${sr.fri?' on':''}' data-a='r' data-k='fri'>${sr.fri?'✓ ':''}Jumu’ah</button></div><div class='note2'>Shown in the Now list and as a banner while the app is open.</div></div>`;
  h.innerHTML=`<div class='ttl phead' role='button' tabindex='0' aria-expanded='false'>Fasting & Jumu’ah <small style='font-weight:400;margin-left:6px'>${E(summary(s))}</small></div>`+b;
  try{applyMin();}catch(e){}}
 function onClick(e){const t=e.target.closest('[data-a]');if(!t||t.tagName==='SELECT')return;const a=t.dataset.a;
  if(a==='t'){toggle(t.dataset.id);return;}
  if(a==='ex'){const r=rec(cur);r.fx=!r.fx;if(r.fx){setId(r,'fast_w',false);SS().qada=qada()+1;}else SS().qada=Math.max(0,qada()-1);save();render();return;}
  if(a==='q'){SS().qada=Math.max(0,qada()+(+t.dataset.d));save();render();return;}
  if(a==='mk'){const r=rec(cur),on=!has(cur,'fast_q');setId(r,'fast_q',on);SS().qada=Math.max(0,qada()+(on?-1:1));save();render();return;}
  if(a==='r'){const o=SR();o[t.dataset.k]=o[t.dataset.k]?0:1;SS().sr=o;save();draw();}}
 function onChange(e){const t=e.target;if(t.dataset&&t.dataset.a==='jm'){SS().jm=t.value;save();render();}}
 /* ---- Learn card ---- */
 function learnHTML(){if(!SD)return '';const f=SD.fasts,grp=(t,ks)=>`<details class='ldt'><summary><b>${t}</b></summary>${ks.map(k=>`<div class='sunr'>${bad(f[k].k==='haram'?'bar':f[k].k==='makruh'?'avoid':f[k].k)}<b>${E(f[k].t)}</b><div class='note2'>${E(f[k].rule)}</div>${evH(f[k].ev)}</div>`).join('')}</details>`;
  const fr=SD.friday;
  return `<div class='card pc min' data-pk='l-sun'><div class='ttl phead' role='button' tabindex='0' aria-expanded='false'>Fasting days & Jumu’ah</div>
   <div class='note2'>Rulings and evidence for what the app counts and reminds. Each hadith shows its collection and grade.</div>
   ${grp('Obligatory (wajib) fasting',['ramadan','qada'])}${grp('Sunnah fasting',['monthu','white','shawwal','arafah','dh','ashura','shaban'])}${grp('Not allowed / better to avoid',['eid','tashreeq','friday','pre'])}
   <details class='ldt'><summary><b>Jumu’ah: obligation and sunnahs</b></summary>${Object.keys(fr).map(k=>`<div class='sunr'><b>${E(fr[k].t)}</b>${fr[k].rule?`<div class='note2'>${E(fr[k].rule)}</div>`:''}${evH(fr[k].ev)}</div>`).join('')}</details>
   <div class='note2'>Hadith numbers follow this app’s Hadith reader numbering; “standard translation” entries are typed with their classical source. Scholars differ on some details (for example, whether Friday ghusl is obligatory or strongly recommended).</div></div>`;}
 const _dl=drawLearn;drawLearn=function(){_dl();const el=document.getElementById('learn');if(!el)return;el.querySelectorAll('[data-pk=l-sun]').forEach(n=>n.remove());el.insertAdjacentHTML('afterbegin',learnHTML());try{applyMin();}catch(e){}};
 /* ---- priority reminders ---- */
 window.SUNH={info:info,now:function(o,t0,T,now,h){const sr=SR();if(!sr.on)return;const i=info(t0),d=x=>has(t0,x),ex=exc(t0),n1=info(addDays(t0,1)),eve=now>=+T.maghrib;
  if(sr.fast){
   if(i.wajib&&!ex){if(now<+T.fajr&&!d('fast_w'))o.push({p:1,t:'Suhoor: intend the Ramadan fast (wajib)',s:'Fajr '+tm(T.fajr),g:'faith'});else if(eve&&!d('fast_w'))o.push({p:2,t:'Log today’s Ramadan fast',s:'',g:'faith'});}
   else if(i.bar.length&&h<14)o.push({p:2,t:'No fasting today: '+i.bar[0].t,s:'',g:'faith'});
   else if(i.sun.length&&!d('sfast')&&now<+T.dhuhr)o.push({p:4,t:'Sunnah fast today: '+i.sun[0].t,s:'Intend before Fajr, or in the morning if you have not eaten',g:'faith'});
   if(eve&&!i.wajib&&n1.wajib&&!i.bar.length)o.push({p:1,t:'Tomorrow is Ramadan: intend the fast (wajib)',s:'',g:'faith'});
   else if(eve&&n1.sun.length&&!n1.wajib&&!i.wajib)o.push({p:5,t:'Tomorrow: '+n1.sun[0].t,s:'Sunnah fast: eat suhoor',g:'faith'});
  }
  if(sr.fri){
   const fri=i.w===5,thu=i.w===4;
   if(fri){const it=o.find(x=>x.k==='dhuhr');if(it&&jmOn()){it.t=it.t.replace(/Pray Dhuhr/,'Jumu’ah prayer (wajib)');it.p=0;}
    else if(jmOn()&&!d('jumuah')&&now>=+T.dhuhr-3600000&&now<+T.dhuhr)o.push({p:1,t:'Jumu’ah prayer soon (wajib)',s:'Dhuhr '+tm(T.dhuhr)+': go early',g:'faith'});
    if(!d('j_ghusl')&&now>=+T.fajr&&now<+T.dhuhr)o.push({p:3,t:'Friday sunnah: ghusl, siwak, best clothes, perfume',s:'',g:'faith'});
    if(!d('j_kahf')&&now>=+T.fajr&&now<+T.maghrib)o.push({p:4,t:'Friday sunnah: Surat al-Kahf',s:'',g:'faith'});
    if(!d('j_dua')&&now>=+T.asr&&now<+T.maghrib)o.push({p:2,t:'Friday: hour of acceptance, dua and salawat',s:'Until Maghrib '+tm(T.maghrib),g:'faith'});}
   else if(thu&&eve&&!has(addDays(t0,1),'j_kahf'))o.push({p:5,t:'Jumu’ah tomorrow: Surat al-Kahf may start tonight',s:'',g:'faith'});}
 }};
 /* ---- banner scheduler (while the app is open) ---- */
 function sched(){const sr=SR();if(!sr.on)return;let T;try{T=ptimes(todayStr());}catch(e){return;}if(!T||!T.fajr||!T.maghrib||!T.dhuhr)return;
  const t0=todayStr(),n=Date.now(),F=(SS().srf=SS().srf||{}),i=info(t0),n1=info(addDays(t0,1)),fri=i.w===5,thu=i.w===4,ev=[];
  if(sr.fast){
   if(i.wajib&&!exc(t0)&&!has(t0,'fast_w'))ev.push([+T.fajr-2400000,'Suhoor time: Ramadan fast today (wajib)','sf']);
   else if(i.sun.length&&!i.wajib)ev.push([+T.fajr-2400000,'Sunnah fast today: '+i.sun[0].t,'ss']);
   if(i.bar.length)ev.push([+T.sunrise||+T.fajr+3600000,'Today is '+i.bar[0].t+': fasting is not allowed','sb']);
   if(n1.wajib&&!i.wajib)ev.push([+T.maghrib+2400000,'Tomorrow is Ramadan: intend the fast (wajib)','se']);
   else if(n1.sun.length&&!n1.wajib&&!i.wajib)ev.push([+T.maghrib+2400000,'Tomorrow: '+n1.sun[0].t+' (sunnah fast)','se']);}
  if(sr.fri){
   if(thu)ev.push([+T.maghrib+1800000,'Jumu’ah tomorrow: prepare your clothes; Surat al-Kahf may start tonight','ft']);
   if(fri){ev.push([(+T.sunrise||+T.fajr+3600000)+1200000,'Friday: ghusl, siwak, perfume, and go early to Jumu’ah','fm']);
    if(jmOn())ev.push([+T.dhuhr-3600000,'Jumu’ah prayer in about an hour (wajib)','fj']);
    ev.push([+T.maghrib-3600000,'Friday: hour of acceptance. Make dua and send salawat','fd']);}}
  let ch=false;ev.forEach(([t,msg,k])=>{const key='sr:'+t0+':'+k;if(n>=t&&n<t+900000&&!F[key]){F[key]=1;ch=true;try{fire({msg:msg,k:key});}catch(e){}}});
  const ks=Object.keys(F).filter(k=>k.indexOf('sr:')===0);if(ks.length>40){ks.sort().slice(0,ks.length-30).forEach(k=>delete F[k]);ch=true;}
  if(ch)save();}
 /* ---- forty-hadith quotes ---- */
 async function loadForty(){try{const r=await fetch('forty_quotes.json',{cache:'no-cache'});if(!r.ok)return;const L=await r.json();let n=0;
   L.forEach(x=>{const en=String(x.en||'').trim();if(!en||QU.some(q=>q[0].slice(0,50)===en.slice(0,50)))return;QU.push([en,String(x.ar||''),String(x.src||'Hadith')]);n++;});
   if(n)try{drawQuote();}catch(e){}}catch(e){}}
 /* ---- boot ---- */
 const _r=render;render=function(){_r();try{draw();}catch(e){}};
 fetch('sunnah.json').then(r=>r.ok?r.json():null).then(j=>{SD=j;try{render();drawLearn();}catch(e){}}).catch(()=>{});
 loadForty();
 try{render();}catch(e){}
 setInterval(sched,60000);setTimeout(sched,4000);
})();
