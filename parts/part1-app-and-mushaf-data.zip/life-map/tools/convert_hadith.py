#!/usr/bin/env python3
"""Convert AhmedBaset/hadith-json (db/by_book/the_9_books/*.json) into the Life Map reader format.

Usage:  python3 convert_hadith.py PATH_TO/db/by_book/the_9_books  OUT_FOLDER [--forties DIR] [--grades grades.json]
Run it from this folder; OUT_FOLDER is normally ../hadith  (upload that folder with the app).
--forties DIR  adds the forty-hadith books found in DIR (nawawi40.json, qudsi40.json, shahwaliullah40.json).
--grades-src DIR  adds gradings to the four Sunan books from the Jammooly1/hadiths-json-files files in DIR
                  (sunan_abi_dawud.json, jami_at_tirmidhi.json, sunan_an_nasai.json, sunan_ibn_majah.json).
                  The two datasets number hadith differently, so grades are matched by the Arabic text (then
                  the English), never by number. A hadith with no match, or with conflicting grades, gets none.
                  A report is printed and saved as grading_report.txt in OUT_FOLDER.

Writes OUT/books.json (index) and OUT/<book>/<chapter>.json (one file per chapter).
Optional grades.json maps "<book>:<hadith number>" to a grading text, e.g. {"tirmidhi:1": "Sahih (Al-Albani)"}.
Only add gradings you have checked against the scholar's published ruling.
"""
import json, os, re, sys, collections

BOOKS = [  # id, file-name hint, English, Arabic
 ('bukhari','bukhari','Sahih al-Bukhari','صحيح البخاري','Six Books'),
 ('muslim','muslim','Sahih Muslim','صحيح مسلم','Six Books'),
 ('abudawud','abudawud','Sunan Abi Dawud','سنن أبي داود','Six Books'),
 ('tirmidhi','tirmidhi','Jami` at-Tirmidhi','جامع الترمذي','Six Books'),
 ('nasai','nasai','Sunan an-Nasa\'i','سنن النسائي','Six Books'),
 ('ibnmajah','ibnmajah','Sunan Ibn Majah','سنن ابن ماجه','Six Books')]
FORTIES = [
 ('nawawi40','nawawi40','Forty Hadith of Imam an-Nawawi','الأربعون النووية','Forty Hadith'),
 ('qudsi40','qudsi40','Forty Hadith Qudsi','الأربعون القدسية','Forty Hadith'),
 ('shahwaliullah40','shahwaliullah40','Forty Hadith of Shah Waliullah','أربعون الشاه ولي الله','Forty Hadith')]

GRADE_FILES = {'abudawud': 'sunan_abi_dawud', 'tirmidhi': 'jami_at_tirmidhi', 'nasai': 'sunan_an_nasai', 'ibnmajah': 'sunan_ibn_majah'}
SAHIHAYN = 'Compiled by its author on the condition of authenticity and accepted by the scholars of the ummah. This is a statement about the book, not a grade for each hadith; reports cited without a full chain, and the few narrations scholars have discussed, are not covered by it.'

def nz(t):
    t = re.sub(r'[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640\u200e\u200f]', '', str(t))
    t = t.replace('ى', 'ي').replace('ة', 'ه')
    t = re.sub(r'[أإآٱ]', 'ا', t)
    return re.sub(r'[\W_]+', '', t, flags=re.U).lower()

def parse_grade(raw):
    """'Sahih (Al-Albani) صحيح (الألباني) حكم' -> 'Sahih (Al-Albani)'. Returns None if it cannot be read safely."""
    raw = re.sub(r'\s+', ' ', raw or '').strip()
    t = re.sub(r'[\u0600-\u06FF]+', '', raw.replace('(Fabricated)', ''))
    out = []
    for lab, who in re.findall(r'([^()]+?)\s*\((Al-Albani|Darussalam)\)', t):
        lab = lab.strip(' ,;'); l = re.sub(r"[’'`,]", '', lab.lower()).strip()
        if re.fullmatch(r'(sahih|sah)( sahih)?', l): c = 'Sahih'
        elif l == 'hasan': c = 'Hasan'
        elif re.fullmatch(r'da ?i?f', l): c = "Da'if"
        elif l.startswith('maud') or l.startswith('mawd'): c = "Maudu'"
        elif who == 'Al-Albani' and re.search('[A-Za-z]', lab): c = lab
        else: continue
        out.append(f'{c} ({who})')
    if out: return ' · '.join(out)
    # Albani's qualified gradings are written only in Arabic (e.g. 'Sahih except one phrase'): keep them as written.
    if raw.endswith('(الألباني) حكم') and re.search(r'[\u0600-\u06FF]', raw):
        body = re.sub(r'[*"]+', '', raw[:-len('(الألباني) حكم')]).strip(' ,;')
        if body: return body + ' (Al-Albani)'
    return None

def load_grades(gdir, bid):
    f = GRADE_FILES.get(bid)
    if not gdir or not f or not os.path.exists(os.path.join(gdir, f + '.json')): return None
    d = json.load(open(os.path.join(gdir, f + '.json'), encoding='utf-8'))
    A = collections.defaultdict(set); Z = collections.defaultdict(set)
    for b in d['all_books']:
        for h in b['hadith_list']:
            g = parse_grade(h.get('grade', ''))
            A[nz(h['arabic_text'])].add(g); Z[nz(h['english_text']) + nz(h['narrator'])].add(g)
    return A, Z

def clean(t):
    return ' '.join(str(t).replace('\\"','"').replace('\u200f','').split())

def txt(v):
    if isinstance(v, dict): return ' '.join(str(x) for x in v.values() if x)
    return '' if v is None else str(v)

def find(src):
    names = {f.lower().replace('_','').replace('-','').replace('.json',''): f for f in os.listdir(src) if f.endswith('.json')}
    return names

def main():
    a = sys.argv[1:]
    if len(a) < 2: sys.exit(__doc__)
    src, out = a[0], a[1]
    opt = lambda k: a[a.index(k) + 1] if k in a and a.index(k) + 1 < len(a) else None
    grades = json.load(open(opt('--grades'), encoding='utf-8')) if opt('--grades') else {}
    todo = [(src, b) for b in BOOKS]
    if opt('--forties'): todo += [(opt('--forties'), b) for b in FORTIES]
    index = []; report = []; gdir = opt('--grades-src')
    for sdir, (bid, hint, en, ar, grp) in todo:
        names = find(sdir)
        f = next((names[k] for k in names if hint in k), None)
        if not f: print('MISSING file for', bid); continue
        d = json.load(open(os.path.join(sdir, f), encoding='utf-8'))
        hs = d.get('hadiths') if isinstance(d, dict) else d
        chs = (d.get('chapters') or []) if isinstance(d, dict) else []
        title = {}
        for c in chs:
            cid = c.get('id'); title[cid] = (txt(c.get('english')), txt(c.get('arabic')))
        groups = {}
        for h in hs:
            groups.setdefault(h.get('chapterId'), []).append(h)
        os.makedirs(os.path.join(out, bid), exist_ok=True)
        chlist = []; total = 0; G = load_grades(gdir, bid); st = collections.Counter()
        for cid in sorted(groups, key=lambda x: (x is None, x)):
            rows = []
            for h in groups[cid]:
                e = h.get('english') or {}
                n = h.get('idInBook', h.get('id'))
                g = grades.get(f'{bid}:{n}') or txt(h.get('grade') or h.get('grades'))
                r = {'n': n, 'ar': clean(h.get('arabic', '')), 'nar': clean(txt(e.get('narrator') if isinstance(e, dict) else '')), 'en': clean(txt(e.get('text') if isinstance(e, dict) else e))}
                if G and not g:
                    c = G[0].get(nz(r['ar'])) or G[1].get(nz(r['en']) + nz(r['nar']))
                    if not c: st['unmatched'] += 1
                    elif len(c) > 1: st['conflict'] += 1
                    else:
                        g = next(iter(c))
                        st['graded' if g else 'matched, no grade in source'] += 1
                if g: r['g'] = g
                rows.append(r)
            json.dump(rows, open(os.path.join(out, bid, f'{cid}.json'), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
            t = title.get(cid, ('', ''))
            chlist.append({'n': cid, 'en': t[0], 'ar': t[1], 'c': len(rows)}); total += len(rows)
        book = {'id': bid, 'en': en, 'ar': ar, 'group': grp, 'count': total, 'chapters': chlist}
        if bid in ('bukhari', 'muslim'): book['note'] = SAHIHAYN
        if G:
            who = 'Al-Albani' if bid == 'abudawud' else 'the Darussalam edition'
            ng = total - st['graded']
            book['note'] = f'Grades are those of {who}, as given in the source data. Scholars sometimes differ on a ruling. {ng} of {total} hadith show no grade because the source has none for them or they were not found in it.'
            line = f'{bid}: {total} hadith | graded {st["graded"]} | matched but no grade in source {st["matched, no grade in source"]} | not found in grading source {st["unmatched"]} | conflicting grades (left ungraded) {st["conflict"]}'
            report.append(line); print(line)
        index.append(book)
        print(bid, total, 'hadith,', len(chlist), 'chapters')
    if report: open(os.path.join(out, 'grading_report.txt'), 'w', encoding='utf-8').write('\n'.join(report) + '\n')
    json.dump({'numbering': 'Hadith numbers as in the source data (Sunnah.com).', 'books': index}, open(os.path.join(out, 'books.json'), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))

main()
