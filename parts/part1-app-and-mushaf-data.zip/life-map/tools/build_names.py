# Builds names.json from tools/names_source.json (virtue lines intentionally dropped: they have no Qur'an/hadith source).
import json
S=json.load(open('tools/names_source.json',encoding='utf8'))
FIX={'المُمعِيدُ':'المُعِيدُ'}
out=[]
for x in S:
    ar=FIX.get(x['name'],x['name']);d=x['meaning_ar'].replace('لسطانه','لسلطانه')
    out.append({'id':x['id'],'ar':ar,'tr':x['transliteration'],'en':x['meaning_en'],'def':d})
assert [o['id'] for o in out]==list(range(1,len(out)+1))
json.dump(out,open('names.json','w',encoding='utf8'),ensure_ascii=False,separators=(',',':'));print(len(out))
