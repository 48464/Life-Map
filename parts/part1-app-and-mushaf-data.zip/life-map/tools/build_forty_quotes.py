# Builds forty_quotes.json: a CURATED, grade-labelled selection from the three forties already in hadith/.
# Text is sliced verbatim from the local English (start..end markers), so wording matches the Hadith reader.
# Run from the app folder:  python3 tools/build_forty_quotes.py
import json,re
S='Sahih'
# (collection, n, start, end, source note)
NAW=[
 (1,'Actions are','he intended.','Bukhari & Muslim · Sahih'),
 (3,'Islam has been built on five','Ramadhan','Bukhari & Muslim · Sahih'),
 (6,'That which is lawful is clear','his honor','Bukhari & Muslim · Sahih'),
 (7,'The deen (religion) is naseehah','common folk.','Muslim · Sahih'),
 (12,'Part of the perfection','concern him','Tirmidhi & others · Hasan'),
 (13,'None of you believes','for himself.','Bukhari & Muslim · Sahih'),
 (15,'Let him who believes in Allah and the Last Day speak good','keep silent','Bukhari & Muslim · Sahih'),
 (17,'Verily Allah has prescribed ihsan','slaughters.','Muslim · Sahih'),
 (18,'Have taqwa','towards the people.','Tirmidhi · Hasan'),
 (20,'If you feel no shame','as you wish','Bukhari · Sahih'),
 (23,'Purity is half','earth.','Muslim · Sahih'),
 (26,'Every joint of a person','charity','Bukhari & Muslim · Sahih'),
 (27,'Righteousness is in good character','finding out about.','Muslim · Sahih'),
 (32,'There should be neither harming','reciprocating harm (dirar)','Ibn Majah & others · Hasan'),
 (34,'Whosoever of you sees an evil','weakest of faith.','Muslim · Sahih'),
 (36,'Whoever removes a worldly grief','Hereafter.','Muslim · Sahih'),
 (39,'Verily Allah has pardoned','under duress.','Ibn Majah & al-Bayhaqi · Hasan'),
 (40,'Be in this world','wayfarer.','Bukhari · Sahih'),
]
QUD=[
 (1,'When Allah decreed the Creation','wrath.','Bukhari & Muslim · Sahih Qudsi'),
 (5,'I am so self-sufficient','associated with Me.','Muslim · Sahih Qudsi'),
 (9,'The first of his actions','failed and lost','Tirmidhi · Sahih Qudsi'),
 (11,'Spend (on charity)','spend on you.','Bukhari & Muslim · Sahih Qudsi'),
 (15,'I am as My servant thinks I am','better than it.','Bukhari & Muslim · Sahih Qudsi'),
 (19,'Pride is my cloak','Hell-fire.','Muslim · Sahih Qudsi'),
 (23,'Where are those who love one another','My shade.','Muslim · Sahih Qudsi'),
 (25,'Whosoever shows enmity','enjoined upon him','Bukhari · Sahih Qudsi'),
 (30,'If My servant likes to meet Me','dislike to meet him.','Bukhari & Muslim · Sahih Qudsi'),
 (37,'I have prepared for My righteous servants','human heart.','Bukhari & Muslim · Sahih Qudsi'),
]
# Hand-typed standard translation of a hadith the local Forty garbles (Muslim 2565, Mon/Thu link to fasting)
EXTRA=[{'en':'The gates of Paradise are opened on Mondays and Thursdays, and every servant who associates nothing with Allah is forgiven, except a man who has enmity between himself and his brother.','ar':'','src':'Hadith · Hadith Qudsi (Forty) #20 · Muslim · Sahih'}]
# Shah Waliullah's Forty: only items I could confirm as Sahih (source note typed by hand)
SW={2:'Bukhari & Muslim · Sahih',4:'Abu Dawud & Tirmidhi · Sahih',5:'Muslim · Sahih',7:'Bukhari & Muslim · Sahih',8:'Muslim · Sahih',
 9:'Muslim · Sahih',17:'Bukhari & Muslim · Sahih',21:'Bukhari & Muslim · Sahih',23:'Bukhari & Muslim · Sahih',24:'Bukhari & Muslim · Sahih',
 25:'Abu Dawud & Tirmidhi · Sahih',32:'Bukhari & Muslim · Sahih',33:'Bukhari & Muslim · Sahih',38:'Bukhari & Muslim · Sahih'}
def en_of(x):
    t=x['en'].replace('\n',' ');t=re.sub(r'\(\d+\)','',t);return re.sub(r'\s+',' ',t)
def slice_(t,a,b):
    i=t.find(a)
    if i<0:return None
    j=t.find(b,i)
    if j<0:return None
    return t[i:j+len(b)].strip(' "“”')
out=[];miss=[]
for fn,lab,spec in [('nawawi40','An-Nawawi’s Forty',NAW),('qudsi40','Hadith Qudsi (Forty)',QUD)]:
    d={x['n']:x for x in json.load(open(f'hadith/{fn}/0.json',encoding='utf8'))}
    for n,a,b,note in spec:
        t=slice_(en_of(d[n]),a,b)
        if not t:miss.append((fn,n));continue
        if t[-1] not in '.!?”")':t+='.'
        out.append({'en':t,'ar':'','src':f'Hadith · {lab} #{n} · {note}'})
d={x['n']:x for x in json.load(open('hadith/shahwaliullah40/0.json',encoding='utf8'))}
for n,note in SW.items():
    out.append({'en':d[n]['en'].strip(),'ar':d[n]['ar'].strip(),'src':f'Hadith · Shah Waliullah’s Forty #{n} · {note}'})
out+=EXTRA
for o in out:
    if '.” We said' in o['en']:o['en']='“'+o['en']+'”'
    o['en']=o['en'].replace(' .','.').replace('  ',' ').strip()
json.dump(out,open('forty_quotes.json','w',encoding='utf8'),ensure_ascii=False,indent=1)
print(len(out),'missing',miss)
