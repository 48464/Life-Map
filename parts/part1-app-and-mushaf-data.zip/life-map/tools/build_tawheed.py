#!/usr/bin/env python3
"""Build the Tawheed reader data from chapter files.

Usage:  python3 build_tawheed.py tawheed_source ../tawheed
Put every chapter file (book_metadata + chapter) in tools/tawheed_source/, run this, then upload the
new tawheed folder beside index.html and raise the version in sw.js. Re-run it after adding files.
Writes OUT/index.json and OUT/<book_id>/<chapter number>.json.
"""
import json, os, sys

def main():
    if len(sys.argv) < 3: sys.exit(__doc__)
    src, out = sys.argv[1], sys.argv[2]
    books = {}
    for f in sorted(os.listdir(src)):
        if not f.endswith('.json'): continue
        try: d = json.load(open(os.path.join(src, f), encoding='utf-8'))
        except Exception as e: print('SKIP (bad JSON)', f, e); continue
        m, c = d.get('book_metadata'), d.get('chapter')
        if not m or not c or not m.get('book_id'): print('SKIP (needs book_metadata.book_id and chapter)', f); continue
        n = c.get('chapter_number', c.get('chapter_id'))
        if n is None: print('SKIP (no chapter_number or chapter_id)', f); continue
        ids = [s.get('segment_id') for s in c.get('segments', [])]
        known = set(ids)
        for cm in c.get('scholarly_commentary', []):
            for ex in cm.get('explanations', []):
                if ex.get('target_segment') not in known: print('WARN', f, 'commentary targets unknown segment', ex.get('target_segment'))
        if len(ids) != len(known): print('WARN', f, 'duplicate segment_id')
        bid = m['book_id']; os.makedirs(os.path.join(out, bid), exist_ok=True)
        json.dump(d, open(os.path.join(out, bid, f'{n}.json'), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
        b = books.setdefault(bid, {'id': bid, 'en': m.get('title_en', bid), 'ar': m.get('title_ar', ''), 'author': m.get('author_en', ''), 'category': m.get('category', ''), 'total': m.get('total_chapters'), 'chapters': {}})
        b['total'] = b['total'] or m.get('total_chapters')
        b['chapters'][n] = {'n': n, 'en': c.get('chapter_title_en', ''), 'ar': c.get('chapter_title_ar', '')}
        print('ok', bid, n)
    lst = []
    for b in books.values():
        b['chapters'] = [b['chapters'][k] for k in sorted(b['chapters'])]; lst.append(b)
    os.makedirs(out, exist_ok=True)
    json.dump({'books': lst}, open(os.path.join(out, 'index.json'), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print(len(lst), 'book(s)')
main()
