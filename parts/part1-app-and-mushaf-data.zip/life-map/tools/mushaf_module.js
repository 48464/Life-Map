/* v35: Quran Mushaf reader (Madani layout, QPC V1 glyphs). Data: mushaf/QPC1/page-XXX.json, fonts/QPC1/pXXX.woff2 (zonetecde/mushaf-layout, branch v2).
   Pages and fonts load when opened and are cached by the service worker for offline use. */
(function(){
 const E=v=>String(v==null?'':v).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const pad=n=>String(n).padStart(3,'0');
 let IX=null,page=1,root=null,busy=0;const PG={},FN={};
 const set=()=>store.set;
 const bms=()=>Array.isArray(set().qbm)?set().qbm:[];
 const surahOf=p=>{if(!IX)return null;let s=IX.surahs[0];IX.surahs.forEach(x=>{if(x.p<=p)s=x;});return s;};
 const juzOf=p=>{if(!IX)return 1;let j=1;IX.juz.forEach((x,i)=>{if(x<=p)j=i+1;});return j;};
 const css=document.createElement('style');css.textContent=`
 .mqo{position:fixed;inset:0;z-index:9000;background:#fbf7ec;color:#1b1b1b;display:none;flex-direction:column;font-family:inherit}
 .mqo.on{display:flex}.mqo *{box-sizing:border-box}
 .mqt{display:flex;align-items:center;gap:8px;padding:10px 12px;border-bottom:1px solid #0002;background:#f3ecd9}
 .mqt b{flex:1;font-size:14px;line-height:1.2}.mqt small{display:block;font-weight:400;opacity:.7}
 .mqt button,.mqb button{border:1px solid #0003;background:#fff8;border-radius:12px;padding:8px 12px;font:inherit;font-size:14px;color:inherit;min-height:40px}
 .mqt button.on{background:#d7a53c;color:#fff;border-color:#d7a53c}
 .mqp{flex:1;overflow:auto;padding:10px 10px 20px;touch-action:pan-y}
 .mqpg{max-width:520px;margin:0 auto;direction:rtl}
 .mql{display:flex;justify-content:space-between;align-items:center;white-space:nowrap;line-height:1.75;min-height:1.75em}
 .mql.c{justify-content:center}.mqw{white-space:pre}
 .mqh{margin:4px 0;padding:2px 0;text-align:center;border:1.5px solid #b08a2e;border-radius:10px;background:#f1e6c4;font-family:'Amiri','Scheherazade New','Noto Naskh Arabic',serif;font-size:1.05em}
 .mqb{display:flex;gap:8px;padding:8px 12px;border-top:1px solid #0002;background:#f3ecd9;align-items:center;justify-content:space-between}
 .mqj{position:absolute;inset:0;background:#fbf7ec;z-index:2;padding:14px;overflow:auto;display:none}.mqj.on{display:block}
 .mqj select,.mqj input{width:100%;padding:10px;border-radius:10px;border:1px solid #0003;font:inherit;background:#fff;margin:4px 0 12px}
 .mqj h3{margin:10px 0 2px;font-size:14px}.mqe{color:#a33;padding:20px;text-align:center}
 @media (prefers-color-scheme:dark){html:not([data-theme=light]) .mqo{background:#151a17;color:#e9e4d2}html:not([data-theme=light]) .mqt,html:not([data-theme=light]) .mqb{background:#1d2420}html:not([data-theme=light]) .mqh{background:#2a3028;border-color:#8a6e2a}html:not([data-theme=light]) .mqj{background:#151a17}html:not([data-theme=light]) .mqj select,html:not([data-theme=light]) .mqj input{background:#222a25;color:inherit}}`;
 document.head.appendChild(css);
 function ensure(){if(root)return root;root=document.createElement('div');root.className='mqo';root.setAttribute('role','dialog');root.setAttribute('aria-label','Quran');
  root.innerHTML=`<div class='mqt'><button data-q='x' aria-label='Close'>✕</button><b id='mqti'></b><button data-q='bm' id='mqbm' aria-label='Bookmark'>☆</button><button data-q='j'>Go to</button></div><div class='mqp' id='mqp'><div class='mqpg' id='mqpg'></div></div><div class='mqb'><button data-q='n'>‹ Next</button><span id='mqpn' style='font-size:13px'></span><button data-q='p'>Previous ›</button></div><div class='mqj' id='mqj'></div>`;
  document.body.appendChild(root);
  root.addEventListener('click',e=>{const b=e.target.closest('[data-q]');if(!b)return;const a=b.dataset.q;
   if(a==='x')close();else if(a==='n')go(page+1);else if(a==='p')go(page-1);else if(a==='bm')bm();else if(a==='j')jump(true);else if(a==='jx')jump(false);
   else if(a==='gp'){const v=parseInt(document.getElementById('mqin').value,10);if(v>=1&&v<=604){jump(false);go(v);}}
   else if(a==='bg'){jump(false);go(+b.dataset.p);}});
  root.addEventListener('change',e=>{const t=e.target;if(t.id==='mqsu'&&t.value){jump(false);go(+t.value);}if(t.id==='mqju'&&t.value){jump(false);go(+t.value);}});
  let x0=null,y0=0;const pe=root.querySelector('#mqp');
  pe.addEventListener('touchstart',e=>{x0=e.touches[0].clientX;y0=e.touches[0].clientY;},{passive:true});
  pe.addEventListener('touchend',e=>{if(x0==null)return;const dx=e.changedTouches[0].clientX-x0,dy=e.changedTouches[0].clientY-y0;x0=null;if(Math.abs(dx)>70&&Math.abs(dx)>Math.abs(dy)*2){if(dx>0)go(page+1);else go(page-1);}},{passive:true});
  document.addEventListener('keydown',e=>{if(!root.classList.contains('on'))return;if(e.key==='ArrowLeft')go(page+1);else if(e.key==='ArrowRight')go(page-1);else if(e.key==='Escape')close();});
  return root;}
 async function font(p){const k='QPC1_p'+pad(p);if(FN[k])return FN[k];FN[k]=(async()=>{try{const f=new FontFace(k,`url(fonts/QPC1/p${pad(p)}.woff2)`);await f.load();document.fonts.add(f);}catch(e){FN[k]=null;throw e;}})();return FN[k];}
 async function base(){if(FN.b)return FN.b;FN.b=(async()=>{try{const f=new FontFace('QPC1BSML','url(fonts/QPC1/QPC1BSML.ttf)');await f.load();document.fonts.add(f);}catch(e){}})();return FN.b;}
 async function data(p){if(PG[p])return PG[p];const r=await fetch(`mushaf/QPC1/page-${pad(p)}.json`);if(!r.ok)throw new Error('page');return PG[p]=await r.json();}
 async function draw(){const host=document.getElementById('mqpg'),my=++busy;host.innerHTML='<div class="mqe" style="color:inherit;opacity:.6">Loading…</div>';
  let d;try{d=await data(page);await Promise.all([font(page),base()]);}catch(e){if(my===busy)host.innerHTML=`<div class='mqe'>Could not load page ${page}. The Mushaf files (mushaf/ and fonts/ folders) must be in the app folder; the first time a page is opened it needs to be online.</div>`;return;}
  if(my!==busy)return;const fam=`QPC1_p${pad(page)}`;let h='';
  d.lines.forEach(l=>{
   if(l.type==='surah-header')h+=`<div class='mqh'>${E(l.text)}</div>`;
   else if(l.type==='basmala')h+=`<div class='mql c' style="font-family:QPC1BSML"><span class='mqw'>${E(l.qpcV1||'')}</span></div>`;
   else h+=`<div class='mql' style="font-family:${fam}">${(l.words||[]).map(w=>`<span class='mqw'>${E(w.qpcV1||w.word)}</span>`).join('')}</div>`;});
  host.innerHTML=h;fit();
  let fs0=null;for(const l of d.lines){if(l.words&&l.words.length){fs0=+l.words[0].location.split(':')[0];break;}}const s=fs0?IX.surahs[fs0-1]:surahOf(page);document.getElementById('mqti').innerHTML=`${E(s?s.en:'')} <small>${E(s?s.ar:'')} · Juz ${juzOf(page)} · Page ${page}</small>`;
  document.getElementById('mqpn').textContent=page+' / 604';document.getElementById('mqbm').className=bms().includes(page)?'on':'';document.getElementById('mqbm').textContent=bms().includes(page)?'★':'☆';
  set().qlast=page;save();document.getElementById('mqp').scrollTop=0;
  [page+1,page-1].forEach(q=>{if(q>=1&&q<=604)data(q).then(()=>font(q)).catch(()=>{});});}
 function fit(){const host=document.getElementById('mqpg'),W=host.clientWidth||320;host.style.fontSize='100px';let mx=1;host.querySelectorAll('.mql:not(.c)').forEach(l=>{let t=0;l.querySelectorAll('.mqw').forEach(w=>t+=w.getBoundingClientRect().width);if(t>mx)mx=t;});
  const fs=Math.max(12,Math.min(34,100*(W-4)/mx));host.style.fontSize=fs+'px';host.querySelectorAll('.mql.c').forEach(l=>{l.style.fontSize='.72em';});}
 window.addEventListener('resize',()=>{if(root&&root.classList.contains('on'))try{fit();}catch(e){}});
 function go(p){p=Math.max(1,Math.min(604,p|0));if(p===page&&document.getElementById('mqpg').children.length>1)return;page=p;draw();}
 function bm(){const l=bms().slice(),i=l.indexOf(page);if(i>=0)l.splice(i,1);else l.push(page);l.sort((a,b)=>a-b);set().qbm=l;save();draw();}
 function jump(on){const j=document.getElementById('mqj');if(!on){j.classList.remove('on');return;}
  j.innerHTML=`<div style='display:flex;justify-content:space-between;align-items:center'><b>Go to</b><button data-q='jx' style='border:1px solid #0003;background:#fff8;border-radius:12px;padding:8px 12px;font:inherit;color:inherit'>Close</button></div>
  <h3>Page (1–604)</h3><div style='display:flex;gap:8px'><input id='mqin' type='number' min='1' max='604' inputmode='numeric' value='${page}'><button data-q='gp' style='border:1px solid #0003;border-radius:12px;padding:0 16px;font:inherit;height:44px;margin-top:4px'>Go</button></div>
  <h3>Surah</h3><select id='mqsu'><option value=''>Choose a surah…</option>${IX.surahs.map(s=>`<option value='${s.p}'>${s.n}. ${E(s.en)} (p. ${s.p})</option>`).join('')}</select>
  <h3>Juz</h3><select id='mqju'><option value=''>Choose a juz…</option>${IX.juz.map((p,i)=>`<option value='${p}'>Juz ${i+1} (p. ${p})</option>`).join('')}</select>
  <h3>Bookmarks</h3>${bms().length?bms().map(p=>{const s=surahOf(p);return `<div style='margin:4px 0'><button data-q='bg' data-p='${p}' style='border:1px solid #0003;background:#fff8;border-radius:12px;padding:10px 12px;font:inherit;color:inherit;width:100%;text-align:left'>★ Page ${p} · ${E(s?s.en:'')}</button></div>`;}).join(''):`<div style='opacity:.6;font-size:14px'>No bookmarks yet. Tap ☆ on a page.</div>`}`;
  j.classList.add('on');}
 async function open(p){if(!IX){try{IX=await (await fetch('mushaf/index.json')).json();}catch(e){alert('Mushaf files not found. Add the mushaf/ and fonts/ folders to the app (see README).');return;}}
  ensure();root.classList.add('on');document.body.style.overflow='hidden';page=0;go(p||set().qlast||1);}
 function close(){if(root)root.classList.remove('on');document.body.style.overflow='';}
 window.MQ={open:open,close:close};
 function card(){const last=+set().qlast||0,s=last?null:null;return `<div class='card pc min' data-pk='l-quran'><div class='ttl phead' role='button' tabindex='0' aria-expanded='false'>Quran (Mushaf) <small style='font-weight:400;margin-left:6px'>${last?'Page '+last:'604 pages'}</small></div>
  <div class='note2'>Madani Mushaf, Hafs ʿan ʿĀṣim, in the standard 15-line page layout. Swipe or use the buttons to turn pages; bookmark any page.</div>
  <div class='chips' style='padding:8px 0;display:flex;gap:8px;flex-wrap:wrap'><button class='chipb on' data-mq='c'>${last?'Continue · page '+last:'Open from page 1'}</button><button class='chipb' data-mq='s'>Al-Fatihah</button><button class='chipb' data-mq='k'>Al-Kahf (p. 293)</button><button class='chipb' data-mq='y'>Ya-Sin (p. 440)</button><button class='chipb' data-mq='m'>Al-Mulk (p. 562)</button></div>
  <div class='note2'>Page layout and glyph fonts: King Fahd Complex QPC V1 (via the open-source mushaf-layout data). Files load as you read and are saved for offline use.</div></div>`;}
 document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('[data-mq]');if(!b)return;const k=b.dataset.mq;open(k==='c'?0:k==='s'?1:k==='k'?293:k==='y'?440:562);});
 const _dl=drawLearn;drawLearn=function(){_dl();const el=document.getElementById('learn');if(!el)return;el.querySelectorAll('[data-pk=l-quran]').forEach(n=>n.remove());el.insertAdjacentHTML('afterbegin',card());try{applyMin();}catch(e){}};
 try{drawLearn();}catch(e){}
})();
